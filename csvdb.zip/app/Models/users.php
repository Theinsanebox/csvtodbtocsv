<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    use HasFactory;

    protected $table='users';
    protected $timestamp=false;

    protected $fillable =['name','email','password']; 

    public static function getuser()
    {
        $recod = DB::table('users')->select('id','name','email','password');
        return $recod;
    }
}
