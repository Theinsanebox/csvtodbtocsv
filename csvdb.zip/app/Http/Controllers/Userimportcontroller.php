<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\imports\usersimport;
use Maatwebsite\Excel\Facades\Excel;

class Userimportcontroller extends Controller
{
    public function show()
    {
        return view('users.import');
    }
    public function store(Request $request)
    {
        $file = $request->file('myfile');

        Excel::import(new usersimport, $file);
    }
}
