<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\usersport;

class Userexportcontroller extends Controller
{
    public function export()
    {
        return (new usersport)->download('users.xlsx');
    }
}
