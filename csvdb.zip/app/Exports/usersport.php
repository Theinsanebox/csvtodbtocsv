<?php

namespace App\Exports;

use App\Models\users;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;

class usersport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
use Exportable;
    public function collection()
    {
        return users::all();
    }
}
