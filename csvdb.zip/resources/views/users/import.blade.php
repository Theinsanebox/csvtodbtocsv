<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>import</title>
</head>
<body>
<center>
	<form action="import" method="post" enctype="multipart/form-data">
		@csrf
		<div>
			<label for="myfile">Select a file:</label>
			<input type="file" id="myfile" name="myfile"><br><br>
			<button type="submit">IMPORT</button>
		</div>
	</form>
</center>
</body>
</html>